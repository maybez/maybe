<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US" sourcelanguage="en">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.cpp" line="160"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="186"/>
        <source>New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="189"/>
        <source>Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="192"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="195"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="200"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="207"/>
        <source>Count...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="209"/>
        <source>Select...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="211"/>
        <source>Apply Script...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="214"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="223"/>
        <location filename="mainwindow.cpp" line="224"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="238"/>
        <location filename="mainwindow.cpp" line="239"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="338"/>
        <source>Created a %1 %2 %3 grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="341"/>
        <source>%1 - Untitled[*]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="351"/>
        <source>Unsaved changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="361"/>
        <source>%1 - Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="367"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="382"/>
        <location filename="mainwindow.cpp" line="408"/>
        <source>%1 - %2[*]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="418"/>
        <source>%1 - Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="494"/>
        <source>Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="mainwindow.cpp" line="495"/>
        <source>A total of %Ln cell(s)%2 are %3 %4.
Their total value is %L5.</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="557"/>
        <source>(and %L1 others...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="560"/>
        <source>Apply Script Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="563"/>
        <source>&amp;Apply Anyway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="563"/>
        <source>&amp;Don&apos;t Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="351"/>
        <source>Save unsaved changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="367"/>
        <source>Failed to open file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="384"/>
        <source>Loaded %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="mainwindow.cpp" line="459"/>
        <source>Selected %Ln cell(s)</source>
        <oldsource>Selected %n cell(s)</oldsource>
        <translation>
            <numerusform>Selected one cell</numerusform>
            <numerusform>Selected %Ln cells</numerusform>
        </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="493"/>
        <location filename="mainwindow.cpp" line="541"/>
        <source> from those selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <source>A total of %Ln cell(s)%1 are %2 %3.
Their total value is %L4.</source>
        <translation type="obsolete">
            <numerusform>One cell%1 is %2 %3.
Its value is %L4.</numerusform>
            <numerusform>A total of %Ln cells%1 are %2 %3.
Their total value is %L4.</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>A total of %Ln cell(s)%1 are %2 %3</source>
        <oldsource>A total of %n cell(s)%1 are %2 %3</oldsource>
        <translation type="obsolete">
            <numerusform>One cell%1 is %2 %3</numerusform>
            <numerusform>A total of %Ln cells%1 are %2 %3</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="mainwindow.cpp" line="561"/>
        <source>%Ln error(s) occurred:
%1</source>
        <oldsource>%n error(s) occurred:
%1</oldsource>
        <translation>
            <numerusform>One error occurred:
%1</numerusform>
            <numerusform>%Ln errors occurred:
%1</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="mainwindow.cpp" line="542"/>
        <source>Finished applying script to %Ln cell(s)%1</source>
        <oldsource>Finished applying script to %n cell(s)%1</oldsource>
        <translation>
            <numerusform>Finished applying script to one cell%1</numerusform>
            <numerusform>Finished applying script to %Ln cells%1</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>MatchForm</name>
    <message>
        <location filename="matchform.cpp" line="48"/>
        <source>%1 - Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="48"/>
        <source>%1 - Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="55"/>
        <source>Count C&amp;ells:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="56"/>
        <source>Select C&amp;ells:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="59"/>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="61"/>
        <source>&lt;=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="63"/>
        <source>&gt;=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="65"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="67"/>
        <source>~=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="75"/>
        <source>Apply to &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="78"/>
        <source>Apply to &amp;Selected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewGridForm</name>
    <message>
        <location filename="newgridform.cpp" line="31"/>
        <source>%1 - New Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newgridform.cpp" line="47"/>
        <source>Random &amp;Initial Values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newgridform.cpp" line="61"/>
        <source>&amp;Rows:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newgridform.cpp" line="62"/>
        <source>&amp;Columns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newgridform.cpp" line="64"/>
        <source>Fixed Initial &amp;Value:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="matchform.cpp" line="29"/>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="30"/>
        <source>&lt;=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="31"/>
        <source>&gt;=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="32"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="matchform.cpp" line="33"/>
        <source>~=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aqp/aqp.cpp" line="147"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aqp/aqp.cpp" line="148"/>
        <source>Do &amp;Not Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScriptForm</name>
    <message>
        <location filename="scriptform.cpp" line="34"/>
        <source>%1 - Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="scriptform.cpp" line="41"/>
        <source>The script will be called once for every cell in the grid. The cell&apos;s value is in variable &lt;tt&gt;cellValue&lt;/tt&gt;, and the cell&apos;s row and column are in variables &lt;tt&gt;cellRow&lt;/tt&gt; and &lt;tt&gt;cellColumn&lt;/tt&gt;. The cell&apos;s value will be set to the script&apos;s result.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="scriptform.cpp" line="54"/>
        <source>Apply to &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="scriptform.cpp" line="57"/>
        <source>Apply to &amp;Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="scriptform.cpp" line="98"/>
        <source>Syntax Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="scriptform.cpp" line="114"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="scriptform.cpp" line="115"/>
        <source>Invalid script on line %1:
%2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.cpp" line="25"/>
        <source>Number Grid</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
