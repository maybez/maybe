function init() {
  print("This is init function")
}

function heartbeat() {
  print("This is heartbeat function")
}

function defend() {
  print("This is defend function")
}
