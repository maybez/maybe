#include "tictactoewidget.h"

TicTacToeWidget::TicTacToeWidget(QWidget *parent)
    : QWidget(parent)
{
}

TicTacToeWidget::~TicTacToeWidget()
{

}
